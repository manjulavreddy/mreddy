package com.listener.batchProcess;

import java.util.ArrayList;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 * Consumes the message from the destination queue using messageListener and 
 * collates the messages in the list and submits the valid batch of buffered
 * messages to the processor after the configured batch size is reached. 
 *
 **/

public class MessageListenerFromQueue implements MessageListener {
	private String consumerName;
	private static final int BATCH_SIZE = 5;
	private static List<String> batch = new ArrayList<>(BATCH_SIZE);
	private static int counter = 0;
	private static int batchesProcessed = 0;
	private MessageReceiverQueue msgReceiveQueue;

	public MessageListenerFromQueue(String consumerName) {
		this.consumerName = consumerName;
	}

	public void onMessage(Message message) {
		TextMessage textMessage = (TextMessage) message;
		List<String> msgList = new ArrayList<String>();
		BatchProcessor processor = new BatchProcessor();
		try {
			msgList.add(textMessage.getText());
			if (msgList.size() != 0) {
				if ("END".equals(textMessage.getText())) {
					msgReceiveQueue.latchCountDown();
					System.out.println("Final batch processed: END");
					processor.process(batch, batchesProcessed);
				} else {
					batch.add(msgList.get(0));
					counter++;
					if (counter == BATCH_SIZE) {
						processor.process(batch, batchesProcessed);
						batch = new ArrayList<>(BATCH_SIZE);
						batchesProcessed++;
						counter = 0;
					}
				}
			}
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}

	public void setMessageReceiverQueue(MessageReceiverQueue msgReceiveQueue) {
		this.msgReceiveQueue = msgReceiveQueue;
	}
	
}
