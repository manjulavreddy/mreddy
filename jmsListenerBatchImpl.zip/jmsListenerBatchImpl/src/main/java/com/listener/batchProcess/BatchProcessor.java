package com.listener.batchProcess;

import java.util.List;

/**
 * Collects the valid batch of messages 
 * @param  total no of batches processed 
 *
 */

public class BatchProcessor {
	public void process(List<String> batch, int batchesProcessed) {
		System.out.println("Total batches processed: " + batchesProcessed);
		System.out.println("Batch content: ");
		batch.forEach(System.out::println);
	}

}
