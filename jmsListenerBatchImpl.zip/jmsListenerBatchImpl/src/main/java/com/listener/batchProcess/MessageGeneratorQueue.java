package com.listener.batchProcess;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Random;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerFactory;
import org.apache.activemq.broker.BrokerService;

/**
 * Create messages using Random generator and send these messages to the 
 * destination queue using messageProducer 
 **/

public class MessageGeneratorQueue {
	public static void main(String[] args) throws URISyntaxException, Exception {

		Connection connection = null;
		BrokerService broker = null;
		try {
			// Broker Service
			broker = BrokerFactory.createBroker(new URI("broker:(tcp://localhost:62266)"));
			broker.start();
			// Producer
			ConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://localhost:62266");
			connection = connectionFactory.createConnection();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Queue queue = session.createQueue("customerQueue");
			MessageProducer producer = session.createProducer(queue);
			
			Random randomgen = new Random();
			int randomNum = randomgen.nextInt(1000);
			System.out.println("random num: " + randomNum);
			
			for (int i = 0; i < randomNum; i++) {
				String payload = String.valueOf(i);
				Message msg = session.createTextMessage(payload);
				System.out.println("Sending text '" + payload + "'");
				producer.send(msg);
			}
			producer.send(session.createTextMessage("END"));
			session.close();
		} finally {
			if (connection != null) {
				connection.close();
			}
		}
	}
}
